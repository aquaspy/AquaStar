﻿package {

	import Image.Preview;

	import Load.LoadController;

	import Network.TCP;

	import flash.display.DisplayObject;
	import flash.display.Loader;
	import flash.display.MovieClip;
	import flash.display.SimpleButton;
	import flash.events.Event;
	import flash.events.IOErrorEvent;
	import flash.events.MouseEvent;
	import flash.events.ProgressEvent;
	import flash.filters.GlowFilter;
	import flash.geom.ColorTransform;
	import flash.net.URLLoader;
	import flash.net.URLLoaderDataFormat;
	import flash.net.URLRequest;
	import flash.system.ApplicationDomain;
	import flash.system.LoaderContext;
	import flash.text.TextField;
	import flash.text.TextFieldType;
	import flash.text.TextFormat;
	import flash.utils.ByteArray;

	public class Main extends MovieClip {

		public static const DEBUG:Boolean = false;
		public static const GLOW:GlowFilter = new GlowFilter(0xFFFFFF, 1, 8, 8, 2, 1, false, false)

		private static const log:TextField = new TextField();

		public static var LOADER_COUNT:uint = 0;

		public const world:* = {
			getQuestValue: function ():Number {
				return -1;
			},
			cellSetup: function (a:*, b:*, c:*):void {
			},
			getMoonPhase: function ():Number {
				return 4
			}
		};

		public const mixer:* = {
			bSoundOn: false
		};

		public static var ROOT:Main;

		private const tcp:TCP = new TCP();

		public static function logEvent(...rest):void {
			var message:String = ""

			for each (var s:String in rest.splice(',')) {
				message += s + " "
			}

			Main.log.appendText(message)
			Main.log.appendText("\n")
		}

		public static function getAchievement(ia1:*, index:int):int {
			if (index < 0 || index > 31) {
				return -1;
			}

			if (ia1 == null) {
				return -1;
			}

			return (ia1 & Math.pow(2, index)) == 0 ? 0 : 1;
		}

		public static function addGlow(displayObject:DisplayObject):void {
			displayObject.filters = [
				GLOW
			];
		}

		public static function avatarBuild(place:MovieClip, linkage:String, gender:String, part:String, applicationDomain:ApplicationDomain):Boolean {
			if (applicationDomain.hasDefinition(linkage + gender + part)) {
				place.removeChildAt(0)

				const movieClip: MovieClip = MovieClip(new (Class(applicationDomain.getDefinition(linkage + gender + part)))());
				movieClip.stopAllMovieClips();

				place.addChildAt(movieClip, 0)

				place.visible = true

				return true
			}

			place.visible = false

			return false
		}

		public static function setPosition(any:MovieClip, maxHeightAndWidth:int, yy:int):void {
			any.x = 0
			any.y = 0

			if (any.height != maxHeightAndWidth || any.width != maxHeightAndWidth) {
				var dif:Number = any.height > any.width ? any.height : any.width

				dif = 1 + ((dif - maxHeightAndWidth) / dif) * -1

				any.height = any.height * dif
				any.width = any.width * dif
			}

			any.x = (300 - any.width >> 1) - any.getBounds(any).x * any.scaleX
			any.y = (yy - any.height >> 1) - any.getBounds(any).y * any.scaleY
		}

		public static function changeColor(movieClip:MovieClip, intColor:Number, strShade:String):void {
			const colorTransform:ColorTransform = new ColorTransform();

			colorTransform.color = intColor;

			switch (strShade.toUpperCase()) {
				case "LIGHT":
					colorTransform.redOffset = colorTransform.redOffset + 100;
					colorTransform.greenOffset = colorTransform.greenOffset + 100;
					colorTransform.blueOffset = colorTransform.blueOffset + 100;
					break;
				case "DARK":
					colorTransform.redOffset = colorTransform.redOffset - 25;
					colorTransform.greenOffset = colorTransform.greenOffset - 50;
					colorTransform.blueOffset = colorTransform.blueOffset - 50;
					break;
				case "DARKER":
					colorTransform.redOffset = colorTransform.redOffset - 125;
					colorTransform.greenOffset = colorTransform.greenOffset - 125;
					colorTransform.blueOffset = colorTransform.blueOffset - 125;
					break;
			}

			movieClip.transform.colorTransform = colorTransform;
		}

		public static function hasLabel(label:String, movieClip:MovieClip):Boolean {
			const currentLabels:Array = movieClip.currentLabels;
			const labelLength:int = movieClip.currentLabels.length;

			for (var i:int = 0; i < labelLength; i++) {
				if (currentLabels[i].name == label) {
					return true;
				}
			}

			return false;
		}

		public var restartButton:SimpleButton;
		public var clearLoaderButton:SimpleButton;
		public var showAllRootChildrenButton:SimpleButton;

		public function Main() {
			Main.ROOT = this

			log.textColor = 0xFFFFFF;
			log.x = 15
			log.y = 30
			log.width = 520
			log.height = 370
			log.defaultTextFormat = new TextFormat("Arial");
			log.type = TextFieldType.INPUT;

			this.addChild(log)

			restartButton.addEventListener(MouseEvent.CLICK, restartTcp);
			addChild(restartButton);

			clearLoaderButton.addEventListener(MouseEvent.CLICK, clearAllLoader);
			addChild(clearLoaderButton);

			showAllRootChildrenButton.addEventListener(MouseEvent.CLICK, showAllRootChildren);
			addChild(showAllRootChildrenButton);

			this.tcp.init();
		}

		private function restartTcp(event:MouseEvent):void {
			this.tcp.init();
		}

		private function clearAllLoader(event:MouseEvent):void {
			LoadController.singleton.clearAllLoader();
		}

		private function showAllRootChildren(event:MouseEvent):void {
			const childrenCount:int = this.numChildren;

			for (var i:int = 0; i < childrenCount; i++) {
				const child:DisplayObject = this.getChildAt(i);
				Main.logEvent(child.name)
			}
		}

		public function get date_server():* {
			return {
				day: 1,
				hours: 19
			};
		}

		public function getServerTime():* {
			return {
				getMonth: function ():Number {
					return 5;
				}
			};
		}

		public function newPreview():Preview {
			const preview:Preview = Preview(Main.ROOT.addChild(new Preview()));
			preview.visible = DEBUG;
			Main.optimizeMovieClip(preview);
			return preview;
		}

		public function mcSetColor(movieClip:MovieClip, strLocation:String, strShade:String):void {
			var lastParent:* = movieClip;

			for (var i:Number = 0; i < 30; i++) {
				if (lastParent.parent != null) {
					const _parent:* = lastParent.parent

					if (_parent is Preview) {
						Preview(_parent).character.setColor(movieClip, strLocation, strShade);
						return;
					}

					lastParent = _parent
				}
			}
		}

		public static function optimizeMovieClip(movieClip: MovieClip): MovieClip {
			movieClip.mouseEnabled = false;
			movieClip.mouseChildren = false;
			movieClip.stopAllMovieClips();

			return movieClip;
		}

	}
}