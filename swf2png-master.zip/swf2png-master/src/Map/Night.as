﻿package Map {

    import flash.display.Sprite;

    public class Night extends Sprite{
	}

}
