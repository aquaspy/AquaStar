package Network {

	import Network.Render.AnyRender;
	import Network.Render.ArmorRender;
	import Network.Render.CharacterDialogRender;
	import Network.Render.CharacterFullRender;
	import Network.Render.CharacterHeadRender;
	import Network.Render.CharacterProfileRender;
	import Network.Render.IconRender;
	import Network.Render.MapBigRender;
	import Network.Render.MapRender;

	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.IOErrorEvent;
	import flash.events.ProgressEvent;
	import flash.events.ServerSocketConnectEvent;
	import flash.net.ServerSocket;
	import flash.net.Socket;

	public class TCP extends Sprite {

		//noinspection JSFieldCanBeLocal
		private var serverSocket:ServerSocket

		public function init():void {
			try {
				if (serverSocket != null) {
					serverSocket.close();

					if (serverSocket.hasEventListener(Event.CONNECT)) {
						serverSocket.addEventListener(Event.CONNECT, connectHandler)
					}

					if (serverSocket.hasEventListener(Event.CLOSE)) {
						serverSocket.addEventListener(Event.CLOSE, onClose)
					}

					serverSocket = null;
				}

				serverSocket = new ServerSocket();

				serverSocket.addEventListener(Event.CONNECT, connectHandler)
				serverSocket.addEventListener(Event.CLOSE, onClose)

				serverSocket.bind(4567)

				serverSocket.listen()

				Main.logEvent("[Network.TCP] Listening on " + serverSocket.localPort)
			} catch (e:SecurityError) {
				Main.logEvent('[Network.TCP]', e.getStackTrace())
			}
		}

		public function connectHandler(event:ServerSocketConnectEvent):void {
			const socket:Socket = event.socket

			socket.addEventListener(ProgressEvent.SOCKET_DATA, socketDataHandler)
			socket.addEventListener(Event.CLOSE, onClientClose)
			socket.addEventListener(IOErrorEvent.IO_ERROR, onIOError)

			if (Main.DEBUG) {
				Main.logEvent("[Network.TCP] Sending connect message")
			}
		}

		public function socketDataHandler(event:ProgressEvent):void {
			const socket:Socket = event.target as Socket

			const message:String = socket.readUTFBytes(socket.bytesAvailable)

			if (Main.DEBUG) {
				Main.logEvent("[Network.TCP] Received: " + message)
			}

			const json:Object = JSON.parse(message);

			try {
				switch (json.type) {
					case 'character':
						new CharacterFullRender(socket, json.data);
						break;
					case 'icon':
						new IconRender(socket, json.data);
						break;
					case 'armor':
						new ArmorRender(socket, json.data);
						break;
					case 'map':
						new MapRender(socket, json.data);
						break;
					case 'map_big':
						new MapBigRender(socket, json.data);
						break;
					case 'profile':
						new CharacterProfileRender(socket, json.data);
						break;
					case 'head':
						new CharacterHeadRender(socket, json.data);
						break;
					case 'dialog':
						new CharacterDialogRender(socket, json.data);
						break;
					default:
						new AnyRender(socket, json.data);
				}
			} catch (e:SecurityError) {
				Main.logEvent('[Network.TCP] socketDataHandler', e.getStackTrace())
			}
		}

		private function onClientClose(event:Event):void {
			if (Main.DEBUG) {
				Main.logEvent("[Network.TCP] onClientClose", event)
			}

			const socket:Socket = event.currentTarget as Socket;

			socket.removeEventListener(ProgressEvent.SOCKET_DATA, socketDataHandler)
			socket.removeEventListener(Event.CLOSE, onClientClose)
			socket.removeEventListener(IOErrorEvent.IO_ERROR, onIOError)
		}

		private function onIOError(errorEvent:IOErrorEvent):void {
			if (Main.DEBUG) {
				Main.logEvent("[Network.TCP] onIOError", errorEvent.text)
			}

			const socket:Socket = errorEvent.currentTarget as Socket;

			socket.removeEventListener(ProgressEvent.SOCKET_DATA, socketDataHandler)
			socket.removeEventListener(Event.CLOSE, onClientClose)
			socket.removeEventListener(IOErrorEvent.IO_ERROR, onIOError)
		}

		private function onClose(event:Event):void {
			Main.logEvent("[Network.TCP] onClose", "Server socket closed by OS", event)
			this.init()
		}

	}

}