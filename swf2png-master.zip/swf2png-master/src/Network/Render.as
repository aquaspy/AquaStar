package Network {

	import Image.Image;
	import Image.Preview;

	import flash.events.ErrorEvent;
	import flash.events.Event;
	import flash.net.Socket;
	import flash.system.ApplicationDomain;
	import flash.system.LoaderContext;
	import flash.utils.setTimeout;

	public class Render {

		public function Render(s:Socket, data:Object, contextAndDomain:Boolean = true) {
			this.socket = s;
			this._data = data;

			if (contextAndDomain) {
				this._applicationDomain = new ApplicationDomain(ApplicationDomain.currentDomain);

				this._loaderContext = new LoaderContext(false, this._applicationDomain);
				this._loaderContext.checkPolicyFile = false;
				this._loaderContext.allowCodeImport = true;
			}

			Main.LOADER_COUNT++;

			this.LOADER_KEY_PREFIX = 'preview_' + Main.LOADER_COUNT;

			setTimeout(function ():void {
				if (preview.parent.contains(preview)) {
					preview.parent.removeChild(preview)
					preview = null;

					if (socket != null) {
						try {
							socket.close();
						} catch (error:Error) {
							if (Main.DEBUG)
								Main.logEvent('onCompleteFinal 2', error.getStackTrace());
						} finally {
							socket = null;
						}
					}

					_data = null;

					onClearLoader();
				}
			}, 5000)
		}

		protected var preview:Preview = Main.ROOT.newPreview();

		protected var LOAD_COUNT:int = 0;
		protected var LOADER_KEY_PREFIX:String;

		private var _data:Object;

		public function get data():Object {
			return _data;
		}

		private var _applicationDomain:ApplicationDomain;

		protected function get applicationDomain():ApplicationDomain {
			return _applicationDomain;
		}

		private var _loaderContext:LoaderContext;

		protected function get loaderContext():LoaderContext {
			return _loaderContext;
		}

		private var socket:Socket;

		protected function onCompleteFinal():void {
			try {
				this.preview.stopAllMovieClips();

				new Image(this.onImageCompleted, this.preview)

				this.preview.parent.removeChild(this.preview)
				this.preview = null;
			} catch (error:Error) {
				Main.logEvent('onCompleteFinal 1', error.getStackTrace());
			}

			if (socket != null) {
				try {
					this.socket.close();
				} catch (error:Error) {
					if (Main.DEBUG)
						Main.logEvent('onCompleteFinal 2', error.getStackTrace());
				} finally {
					socket = null;
				}
			}

			this.socket = null;

			this._data = null;

			onClearLoader();
		}

		protected function onClearLoader():void {
		}

		private function onImageCompleted(base64:String):void {
			try {
				if (socket == null) {
					Main.logEvent('socket is null');
					return;
				}

				this.socket.writeUTFBytes(base64)
				this.socket.flush()
			} catch (e:Error) {
				Main.logEvent(e.message, e.getStackTrace())
			}
		}

		protected function onComplete(event:Event):void {
			this.LOAD_COUNT--;
		}

		protected function onLoadError(errorEvent:ErrorEvent):void {
			this.LOAD_COUNT--;
		}

	}

}
