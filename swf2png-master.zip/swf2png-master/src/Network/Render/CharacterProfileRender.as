package Network.Render {
	import Avatar.Character;
	import Avatar.Profile;

	import Network.Render.Character.*;

	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.Loader;
	import flash.display.MovieClip;
	import flash.events.Event;
	import flash.net.Socket;
	import flash.net.URLRequest;

	public class CharacterProfileRender extends CharacterBaseRender {

		public function CharacterProfileRender(socket:Socket, data:Object) {
			super(socket, data);

			this.preview.imageWidth = 433.3;
			this.preview.imageHeight = 400.6;

			this.preview.character = Character(this.preview.addChild(new Profile(this)));

			const profile:Profile = Profile(this.preview.character);

			profile.username.text = this.data.username;

			if (this.data.guild == null) {
				profile.change_color.guild.visible = false;
			} else {
				profile.change_color.guild.text = this.data.guild;
			}

			profile.level.text = this.data.level;
			profile.ranking_player.text = this.data.ranking_player;

			Main.changeColor(profile.change_color, Number(this.data.intColorName), "light");
			Main.changeColor(profile.background_avatar, Number(this.data.intColorName), "light");

			this.loadBackground();

			loadCharacter();
		}

		override protected function onLoadEntityComplete(event:Event):void {
			const hasHead: Boolean = this.applicationDomain.hasDefinition("mcHead" + this.data.equipment.en.Link);

			const linkage: String = hasHead ? "mcHead" + this.data.equipment.en.Link : this.data.equipment.en.Link;

			const cls:Class = Class(this.applicationDomain.getDefinition(linkage));

			//const entity:MovieClip = MovieClip(this.preview.addChild(new cls()));
			const entity:MovieClip = MovieClip(this.preview.character.addChild(new cls()));

			//entity.mask = Profile(this.preview.character).avatar_mask;

			//this.preview.swapChildrenAt(this.preview.character.getChildIndex(this.preview.character.avatar), this.preview.character.getChildIndex(entity))
			this.preview.character.swapChildren(entity, this.preview.character.avatar)

			Main.optimizeMovieClip(entity);

			if (hasHead) {

				entity.x = 120
				entity.y = 260
			} else {

				entity.x = 95
				entity.y = 470
			}

			Main.addGlow(entity);

			this.onComplete(null);
		}

		private function loadBackground():void {
			this.LOAD_COUNT++

			var loader:Loader = new Loader();
			loader.contentLoaderInfo.addEventListener(Event.COMPLETE, onLoadBackgroundComplete);
			loader.load(new URLRequest(this.data.cover));
		}

		private function onLoadBackgroundComplete(event:Event):void {
			const loader:Loader = event.target.loader as Loader;
			loader.contentLoaderInfo.removeEventListener(Event.COMPLETE, onLoadBackgroundComplete);

			const bitmapData:BitmapData = (loader.content as Bitmap).bitmapData;
			const image:Bitmap = new Bitmap(bitmapData);
			image.smoothing = true;

			const background:MovieClip = Profile(this.preview.character).background_image;
			const maskWidth:Number = 433.3;
			const maskHeight:Number = 262;

			const scaleX:Number = maskWidth / image.width;
			const scaleY:Number = maskHeight / image.height;
			const scale:Number = Math.max(scaleX, scaleY);

			image.width *= scale;
			image.height *= scale;

			image.x = (maskWidth - image.width) >> 1;
			image.y = (maskHeight - image.height) >> 1;

			background.addChild(image);

			onComplete(null);
		}

	}
}
