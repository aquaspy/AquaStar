package Network.Render {
	import Avatar.Character;

	import Network.Render.Character.*;

	import flash.display.MovieClip;
	import flash.events.Event;

	import flash.net.Socket;

	public class CharacterHeadRender extends CharacterBaseRender {

		public function CharacterHeadRender(socket:Socket, data:Object) {
			super(socket, data);

			this.preview.imageWidth = 250;
			this.preview.imageHeight = 250;

			this.preview.character = Character(this.preview.addChild(new Character(this)));

			this.preview.character.width = 1399.95
			this.preview.character.height = 1005.9

			this.preview.character.x = 97.35
			this.preview.character.y = 910.7

			loadCharacter();
		}

		override protected function onLoadEntityComplete(event:Event):void {
			const hasHead: Boolean = this.applicationDomain.hasDefinition("mcHead" + this.data.equipment.en.Link);

			const linkage: String = hasHead ? "mcHead" + this.data.equipment.en.Link : this.data.equipment.en.Link;

			const cls:Class = Class(this.applicationDomain.getDefinition(linkage));

			const entity:MovieClip = MovieClip(this.preview.addChild(new cls()));

			Main.optimizeMovieClip(entity);

			if (hasHead) {
				entity.scaleX = entity.scaleY = 2;

				entity.x = 175
				entity.y = 190
			} else {
				entity.scaleX = entity.scaleY = 4;

				entity.x = 150
				entity.y = 400
			}

			Main.addGlow(entity);

			this.preview.imageWidth = 250;
			this.preview.imageHeight = 250;

			this.onComplete(null);
		}

	}
}
