package Network.Render {

	import Load.LoadController;

	import Network.Render;

	import flash.display.MovieClip;
	import flash.events.Event;
	import flash.geom.Rectangle;
	import flash.net.Socket;
	import flash.system.ApplicationDomain;
	import flash.system.LoaderContext;

	public class IconRender extends Render {

		public function IconRender(socket:Socket, data:Object) {
			super(socket, data, false);

			this.icons = this.data.icons.split(",")

			var loaded:Boolean = false;

			for each (var asset:String in this.data.assets) {
				if (LoadController.loadedAssets.indexOf(asset) === -1) {
					LoadController.singleton.addLoadAsset(this.data.url, asset, this.LOADER_KEY_PREFIX + "_" + asset, onComplete, this.onLoadError);

					this.LOAD_COUNT++;

					LoadController.loadedAssets.push(asset);
				} else {
					loaded = true;
				}
			}

			if (loaded) {
				onComplete(null);
			}
		}

		private var icons:Array = [];

		override protected function get applicationDomain():ApplicationDomain {
			return LoadController.singleton.applicationDomainAsset;
		}

		override protected function get loaderContext():LoaderContext {
			return LoadController.singleton.loaderContextAsset;
		}

		override protected function onClearLoader():void {
			/*for each (var asset:String in this.data.assets) {
				LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "_" + asset);
			}*/
		}

		override protected function onComplete(event:Event):void {
			super.onComplete(event);

			if (this.LOAD_COUNT <= 0) {
				this.preview.imageWidth = 300;
				this.preview.imageHeight = 300;

				for each(var linkage:String in this.icons) {
					if (Main.DEBUG) {
						Main.logEvent("[IconRender]", "onComplete", linkage, this.applicationDomain.hasDefinition(linkage))
					}

					if (!this.applicationDomain.hasDefinition(linkage)) {
						continue;
					}

					const icon:MovieClip = new (this.applicationDomain.getDefinition(linkage) as Class)();

					Main.optimizeMovieClip(icon);

					icon.x = 175
					icon.y = 190

					const position:Rectangle = icon.getBounds(this.preview);

					if (position.height > 200) {
						icon.scaleX = icon.scaleX * (200 / position.height) - 50
						icon.scaleY = icon.scaleY * (200 / position.height) - 50
					}

					Main.setPosition(icon, 300, 300);

					this.preview.addChild(icon);
				}

				this.onCompleteFinal()
			}
		}

	}

}
