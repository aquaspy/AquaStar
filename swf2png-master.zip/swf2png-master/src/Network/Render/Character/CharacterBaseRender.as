package Network.Render.Character {

	import Load.LoadController;

	import flash.display.FrameLabel;

	import flash.display.MovieClip;
	import flash.events.Event;
	import flash.net.Socket;
	import flash.system.ApplicationDomain;

	public class CharacterBaseRender extends CharacterRender {

		public function CharacterBaseRender(socket:Socket, data:Object) {
			super(socket, data);
		}

		protected function loadCharacter():void {
			var ignore:Boolean = false;

			//Entity
			if (this.data.equipment.en.File != "none") {
				this.preview.character.avatar.visible = false;

				loadAsset("en", this.data.equipment.en.File, onLoadEntityComplete);

				ignore = true;
			}

			if (!ignore) {
				//Armor & Class
				loadAsset("ar", 'classes/' + this.data.gender + '/' + this.data.equipment.co.File, onLoadArmorComplete);

				//Helm & Hair
				if (this.data.equipment.he.File != "none" && Main.getAchievement(this.data.ia1, 1) == 0) {
					loadAsset("he", this.data.equipment.he.File, onLoadHelmComplete);
				} else {
					loadAsset("hair", this.data.hair.File, onHairLoadComplete);
				}

				//Weapon
				if (this.data.equipment.Weapon.File != "none") {
					switch (this.data.equipment.Weapon.Type) {
						case "Dagger":
							loadAsset("weapon", this.data.equipment.Weapon.File, onLoadWeaponComplete);
							loadAsset("weaponoff", this.data.equipment.Weapon.File, onLoadWeaponOffComplete);
							break;
						case "Gauntlet":
							loadAsset("weapon", this.data.equipment.Weapon.File, onLoadWeaponGauntletComplete);
							break;
						default:
							loadAsset("weapon", this.data.equipment.Weapon.File, onLoadWeaponComplete);
							this.preview.character.avatar.weaponOff.visible = false;
							break;
					}
				}

				//Cape
				if (this.data.equipment.ba.File != "none" && Main.getAchievement(this.data.ia1, 0) == 0) {
					loadAsset("ba", this.data.equipment.ba.File, onLoadCapeComplete);
				}
			}

			//Pet
			if (this.data.equipment.pe.File != "none" && Main.getAchievement(this.data.ia1, 2) == 0) {
				loadAsset("pe", this.data.equipment.pe.File, onLoadPetComplete);
			}

			//Ground
			if (this.data.equipment.mi.File != "none") {
				loadAsset("mi", this.data.equipment.mi.File, onLoadMiscComplete);
			}
		}

		private function loadAsset(key:String, filePath:String, onComplete:Function):void {
			this.LOAD_COUNT++;
			LoadController.singleton.addLoadAvatar(this.data.url, filePath, this.LOADER_KEY_PREFIX + key, onComplete, this.onLoadError, this.loaderContext);
		}

		protected function onLoadEntityComplete(event:Event):void {
			const cls:Class = Class(this.applicationDomain.getDefinition(this.data.equipment.en.Link));

			//Save height before addChild
			const characterHeight:Number = this.preview.character.height;

			const entity:MovieClip = MovieClip(this.preview.character.addChild(new cls()));

			Main.optimizeMovieClip(entity);

			for each (var label:FrameLabel in entity.currentLabels) {
				if (label.name == "Idle") {
					entity.gotoAndStop("Idle")
					break;
				}
			}

			const scale:Number = (characterHeight / entity.height) * .35;

			entity.scaleX = entity.scaleX >= 0 ? scale : -scale;
			entity.scaleY = scale;

			this.onComplete(null);
		}

		private function onLoadWeaponComplete(event:Event):void {
			if (!Main.avatarBuild(this.preview.character.avatar.weapon, this.data.equipment.Weapon.Link, "", "", this.applicationDomain)) {
				const movieClip: MovieClip = event.target.content;
				movieClip.stopAllMovieClips();

				this.preview.character.avatar.weapon.addChild(movieClip);
			}

			this.onComplete(null);
		}

		private function onLoadWeaponOffComplete(event:Event):void {
			if (!Main.avatarBuild(this.preview.character.avatar.weaponOff, this.data.equipment.Weapon.Link, "", "", this.applicationDomain)) {
				this.preview.character.avatar.weaponOff.addChild(Main.optimizeMovieClip(event.target.content));
			}

			this.preview.character.avatar.weaponOff.visible = true;

			this.onComplete(null);
		}

		private function onLoadWeaponGauntletComplete(event:Event):void {
			if (this.preview.character.avatar.weaponOff.numChildren > 0) {
				this.preview.character.avatar.weaponOff.removeChildAt(0);
			}

			if (this.preview.character.avatar.weapon.numChildren > 0) {
				this.preview.character.avatar.weapon.removeChildAt(0);
			}

			if (this.preview.character.avatar.fronthand.numChildren > 1) {
				this.preview.character.avatar.fronthand.removeChildAt(1);
			}

			if (this.preview.character.avatar.backhand.numChildren > 1) {
				this.preview.character.avatar.backhand.removeChildAt(1);
			}

			const cls:Class = Class(this.applicationDomain.getDefinition(this.data.equipment.Weapon.Link));

			this.preview.character.avatar.fronthand.addChildAt(Main.optimizeMovieClip(new cls()), 1);
			this.preview.character.avatar.fronthand.getChildAt(1).scaleX = 0.8;
			this.preview.character.avatar.fronthand.getChildAt(1).scaleY = 0.8;
			this.preview.character.avatar.fronthand.getChildAt(1).scaleX = this.preview.character.avatar.fronthand.getChildAt(1).scaleX * -1;

			this.preview.character.avatar.backhand.addChildAt(Main.optimizeMovieClip(new cls()), 1);
			this.preview.character.avatar.backhand.getChildAt(1).scaleX = 0.8;
			this.preview.character.avatar.backhand.getChildAt(1).scaleY = 0.8;
			this.preview.character.avatar.backhand.getChildAt(1).scaleX = this.preview.character.avatar.backhand.getChildAt(1).scaleX * -1;

			this.preview.character.avatar.weapon.mcWeapon = new MovieClip();

			this.preview.character.avatar.weaponOff.visible = true;

			this.onComplete(null);
		}

		private function onLoadCapeComplete(e:Event):void {
			const cls:Class = Class(this.applicationDomain.getDefinition(this.data.equipment.ba.Link));

			this.preview.character.avatar.cape.removeChildAt(0);

			this.preview.character.avatar.cape.cape = Main.optimizeMovieClip(new cls());

			this.preview.character.avatar.cape.addChild(this.preview.character.avatar.cape.cape);
			this.preview.character.avatar.cape.visible = true;

			this.onComplete(null);
		}

		private function onLoadHelmComplete(e:Event):void {
			Main.avatarBuild(this.preview.character.avatar.head.helm, "", "", this.data.equipment.he.Link, this.applicationDomain)

			this.preview.character.avatar.head.hair.visible = false;
			this.preview.character.avatar.backhair.visible = false;

			this.onComplete(null);
		}

		private function onLoadMiscComplete(event:Event):void {
			const cls:Class = Class(this.applicationDomain.getDefinition(this.data.equipment.mi.Link));

			this.preview.character.ground.visible = true;

			if (this.preview.character.ground.numChildren > 0) {
				this.preview.character.ground.removeChildAt(0);
			}

			this.preview.character.ground.addChild(Main.optimizeMovieClip(new cls()));

			this.preview.character.ground.scaleX = this.preview.character.avatar.scaleX;
			this.preview.character.ground.scaleY = this.preview.character.avatar.scaleY;

			this.preview.character.ground.mouseChildren = false;
			this.preview.character.ground.mouseEnabled = false;

			this.preview.character.shadow.alpha = 0;

			this.onComplete(null);
		}

		private function onLoadArmorComplete(evt:Event):void {
			if (!Main.avatarBuild(this.preview.character.avatar.head, this.data.equipment.co.Link, this.data.gender, "Head", this.applicationDomain)) {
				if (!Main.avatarBuild(this.preview.character.avatar.head, "mcHead", this.data.gender, "", this.applicationDomain)) {
					Main.avatarBuild(this.preview.character.avatar.head, "mcHead", this.data.gender, "", ApplicationDomain.currentDomain)
				}
			}

			Main.avatarBuild(this.preview.character.avatar.chest, this.data.equipment.co.Link, this.data.gender, "Chest", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.hip, this.data.equipment.co.Link, this.data.gender, "Hip", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.idlefoot, this.data.equipment.co.Link, this.data.gender, "FootIdle", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.backfoot, this.data.equipment.co.Link, this.data.gender, "Foot", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.frontshoulder, this.data.equipment.co.Link, this.data.gender, "Shoulder", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.backshoulder, this.data.equipment.co.Link, this.data.gender, "Shoulder", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.fronthand, this.data.equipment.co.Link, this.data.gender, "Hand", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.backhand, this.data.equipment.co.Link, this.data.gender, "Hand", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.frontthigh, this.data.equipment.co.Link, this.data.gender, "Thigh", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.backthigh, this.data.equipment.co.Link, this.data.gender, "Thigh", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.frontshin, this.data.equipment.co.Link, this.data.gender, "Shin", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.backshin, this.data.equipment.co.Link, this.data.gender, "Shin", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.robe, this.data.equipment.co.Link, this.data.gender, "Robe", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.backrobe, this.data.equipment.co.Link, this.data.gender, "RobeBack", this.applicationDomain)

			//Main.addGlow(this.preview.character.avatar);

			this.onComplete(null);
		}

		private function onHairLoadComplete(event:Event):void {
			Main.avatarBuild(this.preview.character.avatar.head.hair, this.data.hair.Name, this.data.gender, "Hair", this.applicationDomain)

			Main.avatarBuild(this.preview.character.avatar.backhair, this.data.hair.Name, this.data.gender, "HairBack", this.applicationDomain)

			this.onComplete(null);
		}

		private function onLoadPetComplete(e:Event):void {
			const cls:Class = Class(this.applicationDomain.getDefinition(this.data.equipment.pe.Link));

			const pet:MovieClip = MovieClip(new cls());

			pet.x = -40;
			pet.y = 10;

			this.preview.character.addChild(Main.optimizeMovieClip(pet));

			//Main.addGlow(pet);

			this.onComplete(null);
		}

	}
}
