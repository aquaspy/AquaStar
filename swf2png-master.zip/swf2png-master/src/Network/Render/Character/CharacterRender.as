package Network.Render.Character {

	import Load.LoadController;

	import Network.Render;

	import flash.events.Event;
	import flash.net.Socket;
	import flash.utils.setTimeout;

	public class CharacterRender extends Render {

		public function CharacterRender(socket:Socket, data:Object) {
			super(socket, data);
		}

		override protected function onClearLoader():void {
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "weapon");
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "weaponoff");
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "he");
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "ba");
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "ar");
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "co");
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "pe");
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "mi");
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "en");
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX + "hair");
		}

		override protected function onComplete(event:Event):void {
			super.onComplete(event);

			if (this.LOAD_COUNT <= 0) {
				setTimeout(function ():void {
					onCompleteFinal()
				}, 1500)
			}
		}

	}
}
