package Network.Render {

	import Load.LoadController;

	import Network.Render;

	import flash.display.MovieClip;
	import flash.events.Event;
	import flash.geom.Rectangle;
	import flash.net.Socket;

	public class AnyRender extends Render {

		public function AnyRender(socket:Socket, data:Object) {
			super(socket, data);

			LoadController.singleton.addLoadJunk(this.data.url, this.data.file, this.LOADER_KEY_PREFIX, onComplete, this.onLoadError, this.loaderContext);
		}

		override protected function onClearLoader():void {
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX);
		}

		override protected function onComplete(event:Event):void {
			super.onComplete(event);

			const any:MovieClip = this.applicationDomain.hasDefinition(this.data.linkage) ? new (this.applicationDomain.getDefinition(this.data.linkage) as Class)() : event.target.content;

			Main.optimizeMovieClip(any);

			any.x = 175
			any.y = 190

			Main.addGlow(any);

			Main.setPosition(any, this.data.isPet ? 250 : 300, 350);

			this.preview.imageWidth = 300;
			this.preview.imageHeight = 315;

			this.preview.addChild(any);

			this.onCompleteFinal()
		}

	}

}
