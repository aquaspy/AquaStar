package Network.Render {
	import Avatar.Character;

	import Network.Render.Character.*;

	import flash.net.Socket;

	public class CharacterDialogRender extends CharacterBaseRender {

		public function CharacterDialogRender(socket:Socket, data:Object) {
			super(socket, data);

			this.preview.imageWidth = 1307;
			this.preview.imageHeight = 473;

			this.preview.character = Character(this.preview.addChild(new Character(this)));

			this.preview.character.width = 3971
			this.preview.character.height = 2853.15

			this.preview.character.x = 199.25
			this.preview.character.y = 2374.05

			loadCharacter();
		}

	}
}
