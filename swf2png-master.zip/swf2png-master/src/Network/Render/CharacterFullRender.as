package Network.Render {
	import Avatar.Character;

	import Network.Render.Character.*;

	import flash.net.Socket;

	public class CharacterFullRender extends CharacterBaseRender {

		public function CharacterFullRender(socket:Socket, data:Object) {
			super(socket, data);

			this.preview.imageWidth = 1307;
			this.preview.imageHeight = 473;

			this.preview.character = Character(this.preview.addChild(new Character(this)));

			this.preview.character.width = 626.175;
			this.preview.character.height = 449.925;

			this.preview.character.x = 257.45;
			this.preview.character.y = 447.5;

			loadCharacter();
		}

	}
}
