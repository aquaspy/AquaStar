package Network.Render {

	import Avatar.Armor;

	import Load.LoadController;

	import Network.Render;

	import flash.events.Event;
	import flash.net.Socket;

	public class ArmorRender extends Render {

		public function ArmorRender(socket:Socket, data:Object) {
			super(socket, data);

			LoadController.singleton.addLoadJunk(this.data.url, this.data.file, this.LOADER_KEY_PREFIX, onComplete, this.onLoadError, this.loaderContext);
		}

		override protected function onClearLoader():void {
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX);
		}

		override protected function onComplete(event:Event):void {
			const avatar:Armor = new Armor();

			if (!Main.avatarBuild(avatar.avatar.head, this.data.linkage, this.data.gender, "Head", this.applicationDomain)) {
				Main.avatarBuild(avatar.avatar.head, "", "", "mcHead" + this.data.gender, this.applicationDomain)
			}

			Main.avatarBuild(avatar.avatar.chest, this.data.linkage, this.data.gender, "Chest", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.hip, this.data.linkage, this.data.gender, "Hip", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.idlefoot, this.data.linkage, this.data.gender, "FootIdle", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.backfoot, this.data.linkage, this.data.gender, "Foot", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.frontshoulder, this.data.linkage, this.data.gender, "Shoulder", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.backshoulder, this.data.linkage, this.data.gender, "Shoulder", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.fronthand, this.data.linkage, this.data.gender, "Hand", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.backhand, this.data.linkage, this.data.gender, "Hand", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.frontthigh, this.data.linkage, this.data.gender, "Thigh", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.backthigh, this.data.linkage, this.data.gender, "Thigh", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.frontshin, this.data.linkage, this.data.gender, "Shin", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.backshin, this.data.linkage, this.data.gender, "Shin", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.robe, this.data.linkage, this.data.gender, "Robe", this.applicationDomain)

			Main.avatarBuild(avatar.avatar.backrobe, this.data.linkage, this.data.gender, "RobeBack", this.applicationDomain)

			Main.setPosition(avatar, 300, 300);

			this.preview.imageWidth = 300;
			this.preview.imageHeight = 315;

			Main.optimizeMovieClip(avatar);

			this.preview.addChild(avatar);

			this.onCompleteFinal()
		}

	}

}
