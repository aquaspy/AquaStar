package Network.Render {

	import Load.LoadController;

	import Map.Night;

	import Network.Render;

	import flash.display.MovieClip;
	import flash.events.Event;
	import flash.net.Socket;
	import flash.utils.setTimeout;

	public class MapRender extends Render {

		public function MapRender(socket:Socket, data:Object) {
			super(socket, data);

			LoadController.singleton.addLoadMap(this.data.url, this.data.file, this.LOADER_KEY_PREFIX, onComplete, this.onLoadError, this.loaderContext);
		}

		override protected function onClearLoader():void {
			LoadController.singleton.clearLoader(this.LOADER_KEY_PREFIX);
		}

		override protected function onComplete(event:Event):void {
			super.onComplete(event);

			const fakeWorld:MovieClip = new MovieClip()

			fakeWorld.cellSetup = Main.ROOT.world.cellSetup;

			fakeWorld.addChild(new Night())

			const map:MovieClip = MovieClip(fakeWorld.addChild(event.target.content))

			map.x = 0
			map.y = 0

			this.preview.imageWidth = 960;
			this.preview.imageHeight = 550;

			this.preview.addChild(fakeWorld);

			if (Main.hasLabel(this.data.frame, map)) {
				map.gotoAndStop(this.data.frame);
			}

			setTimeout(function ():void {
				onCompleteFinal()
			}, 1500)
		}

	}
}
