package Image {
	import com.adobe.images.PNGEncoder;

	import flash.display.Bitmap;
	import flash.display.BitmapData;

	public dynamic class Image {

		private var _preview:Preview;
		private var _callback:Function;

		public function Image(callback:Function, preview:Preview) {
			_callback = callback;
			_preview = preview;
			outputPNG();
		}

		private function outputPNG():void {
			const bitmapData:BitmapData = new BitmapData(_preview.imageWidth, _preview.imageHeight, true, 0);
			bitmapData.draw(_preview);

			const bitmap:Bitmap = new Bitmap(bitmapData);
			bitmap.smoothing = true;

			_callback(pngEncode(bitmap));

			if (bitmap && bitmap.bitmapData) {
				bitmap.bitmapData.dispose();
				bitmap.bitmapData = null;
			}
		}

		private function pngEncode(bitmap:Bitmap):String {
			if (bitmap.bitmapData) {
				return Base64.encodeByteArray(PNGEncoder.encode(bitmap.bitmapData));
			}

			return "EMPTY";
		}

	}
}
