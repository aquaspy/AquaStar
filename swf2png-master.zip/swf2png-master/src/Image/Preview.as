package Image {

	import Avatar.Character;

	import flash.display.MovieClip;

	public class Preview extends MovieClip {

		public var character:Character;

		public var imageWidth:Number
		public var imageHeight:Number

	}

}
