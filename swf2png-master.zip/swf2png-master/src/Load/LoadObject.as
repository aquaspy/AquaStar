package Load {

	import flash.system.LoaderContext;

	public class LoadObject {

		public var _type:String;

		public var key:String;

		public var url:String;
		public var file:String;

		public var onComplete:Function;
		public var onError:Function;

		public var context:LoaderContext;

		public function LoadObject(_type:String, key:String, url:String, file:String, onComplete:Function, onError:Function, context:LoaderContext) {
			this._type = _type;

			this.key = key;

			this.url = url;
			this.file = file;

			this.onComplete = onComplete;
			this.onError = onError;

			this.context = context;
		}

	}

}
