package Load {

	import flash.display.Loader;
	import flash.events.Event;
	import flash.events.IOErrorEvent;
	import flash.net.URLLoader;
	import flash.net.URLLoaderDataFormat;
	import flash.net.URLRequest;
	import flash.system.ApplicationDomain;
	import flash.system.LoaderContext;
	import flash.utils.ByteArray;
	import flash.utils.Dictionary;

	public class LoadController {

		public static const singleton:LoadController = new LoadController();

		private static const maxConcurrent:int = 100;

		public static const loadedAssets:Vector.<String> = new Vector.<String>();

		public function LoadController() {
			this.applicationDomainAsset = new ApplicationDomain(ApplicationDomain.currentDomain);

			this.loaderContextAsset = new LoaderContext(false, this.applicationDomainAsset);
			this.loaderContextAsset.checkPolicyFile = false;
			this.loaderContextAsset.allowCodeImport = true;
		}

		public var applicationDomainAsset:ApplicationDomain;
		public var loaderContextAsset:LoaderContext;

		private var queue:Vector.<LoadObject> = new Vector.<LoadObject>();

		private var concurrentCount:int = 0;

		private var loaderStack:Dictionary = new Dictionary();

		public function addLoadAsset(url:String, file:String, key:String, onComplete:Function, onError:Function):void {
			queue.push(new LoadObject('asset', key, url, file, onComplete, onError, this.loaderContextAsset));
			loadNext();
		}

		public function addLoadJunk(url:String, file:String, key:String, onComplete:Function, onError:Function, context:LoaderContext):void {
			queue.push(new LoadObject('junk', key, url, file, onComplete, onError, context));
			loadNext();
		}

		public function addLoadMap(url:String, file:String, key:String, onComplete:Function, onError:Function, context:LoaderContext):void {
			queue.push(new LoadObject('map', key, url, file, onComplete, onError, context));
			loadNext();
		}

		public function addLoadAvatar(url:String, file:String, key:String, onComplete:Function, onError:Function, context:LoaderContext):void {
			queue.push(new LoadObject('avatar', key, url, file, onComplete, onError, context));
			loadNext();
		}

		private function onLoadMaster(loadObject:LoadObject):void {
			const fullUrl:String = loadObject.url + '/' + loadObject.file;

			const urlRequest:URLRequest = new URLRequest(fullUrl);

			const urlLoader:URLLoader = new URLLoader();

			urlLoader.dataFormat = URLLoaderDataFormat.BINARY;

			urlLoader.addEventListener(Event.COMPLETE, onLocalComplete);

			function onLocalComplete(event:Event):void {
				urlLoader.removeEventListener(Event.COMPLETE, onLocalComplete);
				urlLoader.removeEventListener(IOErrorEvent.IO_ERROR, onLocalIoError);

				const result:ByteArray = URLLoader(event.target).data as ByteArray;

				const byteLoader:Loader = new Loader();

				byteLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, localOnCompleteByte);

				function localOnCompleteByte(e:Event):void {
					byteLoader.contentLoaderInfo.removeEventListener(Event.COMPLETE, localOnCompleteByte);
					byteLoader.contentLoaderInfo.removeEventListener(IOErrorEvent.IO_ERROR, localOnError);

					try {
						if (Main.DEBUG) {
							Main.logEvent('[LoadController] LOAD', loadObject._type, loadObject.key, loadObject.file)
						}

						if (loadObject.onComplete != null) {
							loadObject.onComplete(e);
						}

						if (Main.DEBUG) {
							Main.logEvent('[LoadController] UNLOAD?', loadObject._type, loadObject.key, loadObject.file)
						}

						clearLoader(loadObject.key);

						loaderStack[loadObject.key] = {
							_type: loadObject._type,
							loader: byteLoader
						};
					} catch (error:Error) {
						Main.logEvent('byteLoader Event.COMPLETE', fullUrl, error.getStackTrace());
					}

					concurrentCount--;

					loadNext();
				}

				byteLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, localOnError);

				function localOnError(event:IOErrorEvent):void {
					byteLoader.contentLoaderInfo.removeEventListener(Event.COMPLETE, localOnCompleteByte);
					byteLoader.contentLoaderInfo.removeEventListener(IOErrorEvent.IO_ERROR, localOnError);

					if (loadObject.onError != null) {
						try {
							loadObject.onError(event);
						} catch (error:Error) {
							Main.logEvent('byteLoader OErrorEvent.IO_ERROR', fullUrl, error.getStackTrace());
						}
					}

					concurrentCount--;

					loadNext();
				}

				byteLoader.loadBytes(result, loadObject.context);
			}

			urlLoader.addEventListener(IOErrorEvent.IO_ERROR, onLocalIoError);

			function onLocalIoError(event:IOErrorEvent):void {
				urlLoader.removeEventListener(Event.COMPLETE, onLocalComplete);
				urlLoader.removeEventListener(IOErrorEvent.IO_ERROR, onLocalIoError);

				if (loadObject.onError != null) {
					try {
						loadObject.onError(event);
					} catch (error:Error) {
						Main.logEvent('urlLoader OErrorEvent.IO_ERROR', fullUrl, error.getStackTrace());
					}
				}

				concurrentCount--;

				loadNext();
			}

			urlLoader.load(urlRequest);
		}

		public function clearAllLoader():void {
			for (var key:String in loaderStack) {
				if (Main.DEBUG) {
					Main.logEvent('[LoadController] Clear All Loader')
				}

				Loader(loaderStack[key].loader).unloadAndStop();

				delete loaderStack[key];
			}
		}

		public function clearLoader(key:String):void {
			if (key in loaderStack) {
				if (Main.DEBUG) {
					Main.logEvent('[LoadController] Clear Loader', key)
				}

				Loader(loaderStack[key].loader).unloadAndStop();

				delete loaderStack[key];
			}
		}

		public function clearLoaderByType(_type:String):void {
			for (var key:String in loaderStack) {
				if (loaderStack[key]._type == _type) {
					if (Main.DEBUG) {
						Main.logEvent('[LoadController] Clear Loader by Type', key, _type)
					}

					Loader(loaderStack[key].loader).unloadAndStop();

					delete loaderStack[key];
				}
			}
		}

		private function loadNext():void {
			if (queue.length > 0 && concurrentCount < maxConcurrent) {
				concurrentCount++;
				onLoadMaster(queue.shift());
			}
		}

	}

}
