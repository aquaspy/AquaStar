package Avatar {

    import Network.Render;

    import flash.display.MovieClip;

    import flash.text.TextField;

    public class Profile extends Character {

        public var username: TextField;
        public var level: TextField;
        public var ranking_player: TextField;

        public var change_color: MovieClip;
        public var background_avatar: MovieClip;
        public var background_image: MovieClip;

        public function Profile(render:Render) {
            super(render);
        }

    }
}
