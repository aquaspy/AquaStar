﻿package Avatar {

	import flash.display.MovieClip;

	public dynamic class Armor extends MovieClip {

		public var avatar:MovieClip

	}
}