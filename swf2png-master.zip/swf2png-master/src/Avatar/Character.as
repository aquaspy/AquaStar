﻿package Avatar {

	import Network.Render;

	import flash.display.MovieClip;

	public class Character extends MovieClip {

		public function Character(render:Render) {
			this.render = render;

			this.avatar.cape.visible = false
			this.avatar.backhair.visible = false
			this.avatar.robe.visible = false
			this.avatar.backrobe.visible = false
		}

		public var avatar:MovieClip;
		public var shadow:MovieClip;
		public var ground:MovieClip;

		private var render:Render;

		public function setColor(movieClip:MovieClip, strLocation:String, strShade:String):void {
			const intColor:Number = Number(this.render.data[("intColor" + strLocation)]);

			movieClip.isColored = true;
			movieClip.intColor = intColor;
			movieClip.strLocation = strLocation;
			movieClip.strShade = strShade;

			Main.changeColor(movieClip, intColor, strShade);
		}

	}
}