﻿	local var accessibilityPropertyNames : Array;
