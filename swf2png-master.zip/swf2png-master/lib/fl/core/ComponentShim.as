﻿// Decompiled by AS3 Sorcerer 5.56
// www.as3sorcerer.com

//fl.core.ComponentShim

package fl.core
{
    import flash.display.MovieClip;

    public dynamic class ComponentShim extends MovieClip 
    {


    }
}//package fl.core

