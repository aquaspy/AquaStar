# SWF2PNG

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)  
![ActionScript](https://img.shields.io/badge/ActionScript-3.0-orange)
![Adobe AIR](https://img.shields.io/badge/Adobe%20AIR-TCP%20Sockets-red)
![Image](https://img.shields.io/badge/Image-Base64%20PNG-blue)
![Data](https://img.shields.io/badge/Data-JSON-green)
![Category](https://img.shields.io/badge/Category-Asset%20Preview-lightgrey)

A TCP-based assets preview server built in ActionScript 3 for Flash/AIR content. It runs a local server that listens for JSON requests to render SWF-based assets (characters, items, armor, maps, icons), captures a bitmap, then returns a Base64-encoded PNG. Originally used with AQWorlds-style assets; see notes below.

- Community-focused: this tool helps preview SWF-based assets.
- References to AQWorlds are for compatibility/context. If you point `url` at official hosts, make sure your usage follows their terms.

## Features

- **TCP Server**: Listens on port 4567 for incoming preview requests
- **Multiple Render Types**:
  - Character (full, head, profile, dialog)
  - Armor/equipment previews
  - Map rendering (standard and large)
  - Icon generation
  - Generic asset rendering
- **Image Export**: Converts rendered MovieClips to Base64-encoded PNG images
- **Debug Interface**: Built-in logging and control buttons

## Project Structure

- `src/` — Main source code directory
  - `Main.as` — Entry point and TCP server setup
  - `Avatar/` — Character and armor rendering classes
  - `Image/` — Image capture and Base64 encoding
  - `Load/` — Asset loading and caching system
  - `Map/` — Map rendering functionality
  - `Network/` — TCP networking and render dispatching
    - `Render/` — Specialized renderers for different asset types
  - `com/adobe/` — Adobe utility libraries (crypto, JSON, etc.)
- `lib/fl/` — Flash UI components and controls
- `item-preview.fla` — Flash project file
- `Item.swf` — Compiled SWF application

## Usage

### Running the Application

1.  Compile: Open `item-preview.fla` in Adobe Animate/Flash and publish as an Adobe AIR application to generate the AIR package.
2.  Execute: Run the application using Adobe AIR Runtime (TCP socket functionality requires AIR).
3.  Server: The application automatically starts a TCP server on port 4567.

### Sending Requests

Send JSON requests to `localhost:4567` with the following structure:

```json
{
  "type": "character|icon|armor|map|map_big|profile|head|dialog",
  "data": {
    // Render-specific data object
  }
}
```

#### Complete Request Examples

> You’ll typically point `url` to your asset mirror or a permitted host.

**Character Rendering (type: "character"):**
```json
{
  "type": "character",
  "data": {
    "url": "https://game.aq.com/game/gamefiles/",
    "gender": "M",
    "ia1": 0,
    "equipment": {
      "en": { "File": "none", "Link": "" },
      "co": { "File": "SomeClass.swf", "Link": "rSomeClass" },
      "he": { "File": "none", "Link": "" },
      "Weapon": { "File": "SomeWeapon.swf", "Type": "Sword", "Link": "rSomeWeapon" },
      "ba": { "File": "none", "Link": "" },
      "pe": { "File": "none", "Link": "" },
      "mi": { "File": "none", "Link": "" }
    },
    "hair": { "File": "hair/Hair_101.swf", "Name": "rHair101" },
    "intColorSkin": 16777215,
    "intColorHair": 8421504,
    "intColorEye": 255,
    "intColorBase": 16711680,
    "intColorTrim": 16777215,
    "intColorAccessory": 65280
  }
}
```

Notes:
- `co.File` is appended internally as `classes/{gender}/{co.File}`.
- Set `en.File` to a SWF and `en.Link` to a symbol to render an entity instead of a standard avatar.
- `ia1` is a bitmask controlling hidden equipment (cape, helm, pet). Use `0` for visible defaults.

**Armor Preview (type: "armor"):**
```json
{
  "type": "armor",
  "data": {
    "url": "https://game.aq.com/game/gamefiles/",
    "file": "classes/M/SomeClass.swf",
    "linkage": "rSomeClass",
    "gender": "M"
  }
}
```

**Item/Icon Symbols (type: "icon"):**
```json
{
  "type": "icon",
  "data": {
    "url": "https://game.aq.com/game/gamefiles/",
    "assets": [
      "items/Icons.swf",
      "classes/M/SomeClass.swf"
    ],
    "icons": "iSomeItem,iAnotherSymbol"
  }
}
```

**Map Rendering (type: "map"):**
```json
{
  "type": "map",
  "data": {
    "url": "https://assets.example.com/maps",
    "file": "battleon.swf",
    "frame": "Enter"
  }
}
```

**Large Map Rendering (type: "map_big"):**
```json
{
  "type": "map_big",
  "data": {
    "url": "https://assets.example.com/maps",
    "file": "battleon.swf",
    "frame": "Enter"
  }
}
```

**Character Profile (type: "profile"):**
```json
{
  "type": "profile",
  "data": {
    "url": "https://game.aq.com/game/gamefiles/",
    "username": "Player123",
    "guild": "Community Guild",
    "level": 150,
    "ranking_player": "Legend",
    "intColorName": 13369395,
    "cover": "https://assets.example.com/images/cover.jpg",
    "gender": "M",
    "ia1": 0,
    "equipment": {
      "en": { "File": "none", "Link": "" },
      "co": { "File": "SomeClass.swf", "Link": "rSomeClass" },
      "he": { "File": "none", "Link": "" },
      "Weapon": { "File": "SomeWeapon.swf", "Type": "Sword", "Link": "rSomeWeapon" },
      "ba": { "File": "none", "Link": "" },
      "pe": { "File": "none", "Link": "" },
      "mi": { "File": "none", "Link": "" }
    },
    "hair": { "File": "hair/Hair_101.swf", "Name": "rHair101" },
    "intColorSkin": 16777215,
    "intColorHair": 8421504,
    "intColorEye": 255
  }
}
```

**Character Head/Avatar (type: "head"):**
```json
{
  "type": "head",
  "data": {
    "url": "https://game.aq.com/game/gamefiles/",
    "gender": "F",
    "ia1": 0,
    "equipment": {
      "en": { "File": "none", "Link": "" },
      "co": { "File": "SomeClass.swf", "Link": "rSomeClass" },
      "he": { "File": "helms/Helm_3001.swf", "Link": "rHelm3001" },
      "Weapon": { "File": "none", "Type": "", "Link": "" },
      "ba": { "File": "none", "Link": "" },
      "pe": { "File": "none", "Link": "" },
      "mi": { "File": "none", "Link": "" }
    },
    "hair": { "File": "hair/Hair_102.swf", "Name": "rHair102" },
    "intColorSkin": 16777215,
    "intColorHair": 4210752,
    "intColorEye": 65280
  }
}
```

**Character Dialog (type: "dialog"):**
```json
{
  "type": "dialog",
  "data": {
    "url": "https://game.aq.com/game/gamefiles/",
    "gender": "M",
    "ia1": 0,
    "equipment": {
      "en": { "File": "none", "Link": "" },
      "co": { "File": "SomeClass.swf", "Link": "rSomeClass" },
      "he": { "File": "none", "Link": "" },
      "Weapon": { "File": "SomeWeapon.swf", "Type": "Sword", "Link": "rSomeWeapon" },
      "ba": { "File": "none", "Link": "" },
      "pe": { "File": "none", "Link": "" },
      "mi": { "File": "none", "Link": "" }
    },
    "hair": { "File": "hair/Hair_101.swf", "Name": "rHair101" },
    "intColorSkin": 16777215,
    "intColorHair": 8421504,
    "intColorEye": 255
  }
}
```

### Debug Controls

The application includes debug buttons for:
- **Restart TCP**: Restart the TCP server
- **Clear Loader**: Clear all loaded assets
- **Show Children**: List all display objects

### Response Format

The server responds with Base64-encoded PNG image data that can be decoded and displayed by the client application.

## Requirements

-  **Adobe Animate/Flash Professional** or compatible IDE
-  **ActionScript 3.0** support
-  **Adobe AIR Runtime** (required for TCP socket functionality)
-  **Adobe AIR SDK** for compilation and packaging

## Development

### Building

```bash
# Using Adobe Animate
1. Open  item-preview.fla
2. File > Publish Settings > Adobe AIR
3. Configure AIR application settings
4. Publish
```

### Debugging
Set `Main.DEBUG = true` to enable verbose logging of:
- TCP connection events
- Asset loading progress  
- Render pipeline execution
- Error stack traces

---

## Contributing

Contributions, issues, and feature requests are welcome!
Feel free to fork the repo and submit pull requests.

---

## License

This project is licensed under the MIT License.
